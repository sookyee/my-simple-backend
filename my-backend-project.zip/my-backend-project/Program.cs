﻿namespace my_backend_project;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public class Program
{
    public static void Main()
    {
        string jsonString = @"
{
  ""recipients"": [
    {
      ""tags"": [
        ""promo"",
        ""buyer"",
        ""clicker"",
        ""non-clicker""
      ],
      ""name"": ""Maura Hickman"",
      ""id"": 0
    },
    {
      ""tags"": [
        ""shopping"",
        ""clicker""
      ],
      ""name"": ""Luisa Rutledge"",
      ""id"": 1
    },
    {
      ""tags"": [
        ""shopping"",
        ""non-clicker""
      ],
      ""name"": ""Pearson Marquez"",
      ""id"": 2
    },
    {
      ""tags"": [
        ""promo"",
        ""clicker"",
        ""non-clicker""
      ],
      ""name"": ""Fern Wise"",
      ""id"": 3
    },
    {
      ""tags"": [],
      ""name"": ""Chaney Browning"",
      ""id"": 4
    },
    {
      ""tags"": [
        ""buyer"",
        ""clicker""
      ],
      ""name"": ""Elena Vega"",
      ""id"": 5
    },
    {
      ""tags"": [
        ""shopping""
      ],
      ""name"": ""Ruby Goff"",
      ""id"": 6
    },
    {
      ""tags"": [
        ""buyer""
      ],
      ""name"": ""Patrica Juarez"",
      ""id"": 7
    },
    {
      ""tags"": [
        ""promo"",
        ""non-clicker""
      ],
      ""name"": ""Alexandra Jacobson"",
      ""id"": 8
    },
    {
      ""tags"": [
        ""clicker""
      ],
      ""name"": ""Eloise Buckley"",
      ""id"": 9
    },
    {
      ""tags"": [
        ""clicker""
      ],
      ""name"": ""Diann Rodgers"",
      ""id"": 10
    },
    {
      ""tags"": [
        ""promo"",
        ""non-clicker""
      ],
      ""name"": ""Burt Hampton"",
      ""id"": 11
    },
    {
      ""tags"": [
        ""shopping"",
        ""buyer"",
        ""clicker""
      ],
      ""name"": ""Sylvia Norman"",
      ""id"": 12
    },
    {
      ""tags"": [],
      ""name"": ""Dominguez Morrison"",
      ""id"": 13
    },
    {
      ""tags"": [
        ""campaign"",
        ""shopping"",
        ""buyer""
      ],
      ""name"": ""Jana Stevenson"",
      ""id"": 14
    },
    {
      ""tags"": [],
      ""name"": ""Holmes Stevens"",
      ""id"": 15
    },
    {
      ""tags"": [
        ""promo"",
        ""shopping"",
        ""buyer"",
        ""clicker""
      ],
      ""name"": ""Colon Reynolds"",
      ""id"": 16
    },
    {
      ""tags"": [
        ""campaign"",
        ""clicker""
      ],
      ""name"": ""Harrell Johnston"",
      ""id"": 17
    }
  ]
}
";


        JObject json = JObject.Parse(jsonString);
        JArray recipientsArray = (JArray)json["recipients"];
        List<Recipient> recipients = new List<Recipient>();

        foreach (var recipient in recipientsArray)
        {
            string name = recipient["name"].ToString();
			HashSet<string> tags = new HashSet<string>();
			foreach(var recipientTags in recipient["tags"]) {
				tags.Add(recipientTags.ToString());
			}
            recipients.Add(new Recipient { Name = name, Tags = tags });
        }

        List<string> commonTagPairs = new List<string>();

        // Iterate through recipients and find pairs with common tags
        for (int i = 0; i < recipients.Count; i++)
        {
            for (int j = i + 1; j < recipients.Count; j++)
            {
                int commonTagsCount = CountCommonTags(recipients[i], recipients[j]);
                if (commonTagsCount >= 2)
                {
                     commonTagPairs.Add(recipients[i].Name + ", " + recipients[j].Name);
                }
            }
        }

        // Output pairs with common tags
        foreach (string pair in commonTagPairs)
        {
            Console.WriteLine(pair);
        }
    }

    // Function to count common tags between two recipients
    public static int CountCommonTags(Recipient recipientOne, Recipient recipientTwo)
    {
        int count = 0;
        foreach (string tag in recipientOne.Tags)
        {
            if (recipientTwo.Tags.Contains(tag))
            {
                count++;
            }
        }
        return count;
    }
}

public class Recipient
{
    public string Name { get; set; }
    public HashSet<string> Tags { get; set; }
}
