Step 1:Download folder and open the .sln in Visual studio (with .NET sdk installed)
Step 2. Run dotnet restore in the NPM terminal to restore package dependencies
