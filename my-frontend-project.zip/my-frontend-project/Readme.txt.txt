Step 1: Download folder and open folder using Visual Studio or Visual Studio Code.
Step 2: Install the Live Server extension from the VS Code Marketplace for html.
Step 3: Right-click on the age.html file and select Open with Live Server.
Page will open in a default stated port using url <base_url>/age.html