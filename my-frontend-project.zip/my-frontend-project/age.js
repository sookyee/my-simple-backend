function categoriseAge(age) {
    // Define age categories
    var categories = {
        toddler: { start: 0, end: 2 },
        child: { start: 3, end: 11 },
        adolescent: { start: 12, end: 17 },
        adult: { start: 18, end: Infinity } // Infinity represents any age above 17
    };

    // Find the corresponding category for the given age
    for (var category in categories) {
        if(categories[category]!=null){
         if (age >= categories[category].start && age <= categories[category].end) {
            return category;
          }
        }
    }

    // Return null if no category matches the age
    return null;
}